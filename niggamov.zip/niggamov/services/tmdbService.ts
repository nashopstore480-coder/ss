import { TMDB_API_KEY, TMDB_BASE_URL } from '../constants';
import { SearchResult, Movie, TVShow, TVSeasonDetails, Media } from '../types';

const headers = {
  'Authorization': `Bearer ${TMDB_API_KEY}`,
  'accept': 'application/json'
};

const fetchData = async <T,>(endpoint: string, params: Record<string, string> = {}): Promise<T> => {
  const urlParams = new URLSearchParams({ language: 'en-US', ...params });
  const response = await fetch(`${TMDB_BASE_URL}/${endpoint}?${urlParams.toString()}`, { headers });
  if (!response.ok) {
    throw new Error(`Failed to fetch from TMDB: ${response.statusText}`);
  }
  return response.json();
};

export const getPopularMovies = async (): Promise<Movie[]> => {
  const data = await fetchData<{ results: Movie[] }>('movie/popular');
  return data.results;
};

export const getPopularTVShows = async (): Promise<TVShow[]> => {
  const data = await fetchData<{ results: TVShow[] }>('tv/popular');
  return data.results;
};

export const getTopRatedMovies = async (): Promise<Movie[]> => {
  const data = await fetchData<{ results: Movie[] }>('movie/top_rated');
  return data.results;
};

export const getNowPlayingMovies = async (): Promise<Movie[]> => {
    const data = await fetchData<{ results: Movie[] }>('movie/now_playing');
    return data.results;
};

export const getRandomPopularMovie = async (): Promise<Movie> => {
    const randomPage = Math.floor(Math.random() * 10) + 1; // Get a random page from the first 10
    const data = await fetchData<{ results: Movie[] }>('movie/popular', { page: randomPage.toString() });
    const randomIndex = Math.floor(Math.random() * data.results.length);
    return data.results[randomIndex];
}

export const searchMedia = async (query: string): Promise<SearchResult[]> => {
  if (!query.trim()) return [];
  const data = await fetchData<{ results: SearchResult[] }>(`search/multi`, { query: encodeURIComponent(query), include_adult: 'false' });
  return data.results.filter(r => (r.media_type === 'movie' || r.media_type === 'tv') && r.poster_path);
};

export const getMovieDetails = async (id: string): Promise<Movie> => {
  return fetchData<Movie>(`movie/${id}`, { append_to_response: 'credits,recommendations' });
};

export const getTVShowDetails = async (id: string): Promise<TVShow> => {
  return fetchData<TVShow>(`tv/${id}`, { append_to_response: 'credits,recommendations' });
};

export const getTVSeasonDetails = async (id: string, seasonNumber: number): Promise<TVSeasonDetails> => {
    return fetchData<TVSeasonDetails>(`tv/${id}/season/${seasonNumber}`);
};