import { Media } from '../types';

const HISTORY_KEY = 'niggamov_viewingHistory';
const MAX_HISTORY_ITEMS = 20;

/**
 * Retrieves the viewing history from localStorage.
 * @returns {Media[]} An array of media items from the history.
 */
export const getViewingHistory = (): Media[] => {
    try {
        const historyJson = localStorage.getItem(HISTORY_KEY);
        if (!historyJson) {
            return [];
        }
        const history = JSON.parse(historyJson);
        return Array.isArray(history) ? history : [];
    } catch (error) {
        console.error("Failed to parse viewing history:", error);
        localStorage.removeItem(HISTORY_KEY);
        return [];
    }
};

/**
 * Adds a media item to the viewing history in localStorage.
 * The most recently watched item is placed at the beginning of the list.
 * @param {Media} media - The media item to add.
 */
export const addToViewingHistory = (media: Media): void => {
    if (!media || !media.id) {
        return;
    }

    try {
        let history = getViewingHistory();
        
        // Remove any existing entry for the same media to move it to the front
        const filteredHistory = history.filter(item => item.id !== media.id);
        
        // Add the new item to the beginning of the array
        const newHistory = [media, ...filteredHistory];
        
        // Limit the history size
        if (newHistory.length > MAX_HISTORY_ITEMS) {
            newHistory.length = MAX_HISTORY_ITEMS;
        }
        
        localStorage.setItem(HISTORY_KEY, JSON.stringify(newHistory));
    } catch (error) {
        console.error("Failed to add to viewing history:", error);
    }
};
