const AD_REPORTS_KEY = 'niggamov_adReports';

/**
 * Retrieves ad reports from localStorage.
 * @returns {Record<number, number>} An object where keys are server IDs and values are report counts.
 */
export const getAdReports = (): Record<number, number> => {
    try {
        const reportsJson = localStorage.getItem(AD_REPORTS_KEY);
        if (!reportsJson) {
            return {};
        }
        const reports = JSON.parse(reportsJson);
        // Basic validation to ensure it's an object of numbers
        if (typeof reports === 'object' && reports !== null && !Array.isArray(reports)) {
            return reports;
        }
        return {};
    } catch (error) {
        console.error("Failed to parse ad reports:", error);
        localStorage.removeItem(AD_REPORTS_KEY);
        return {};
    }
};

/**
 * Reports an ad for a specific server, incrementing its report count.
 * @param {number} serverId - The ID of the server to report.
 */
export const reportAdForServer = (serverId: number): void => {
    if (!serverId) return;

    try {
        const reports = getAdReports();
        reports[serverId] = (reports[serverId] || 0) + 1;
        localStorage.setItem(AD_REPORTS_KEY, JSON.stringify(reports));
    } catch (error) {
        console.error("Failed to report ad for server:", error);
    }
};
