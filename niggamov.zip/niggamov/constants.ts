
export const TMDB_API_KEY = 'eyJhbGciOiJIUzI1NiJ9.eyJhdWQiOiIwYTk1NzRmZDcxMjRkNmI5ZTUyNjA4ZWEzNWQ2NzdiNCIsIm5iZiI6MTczNzU5MDQ2NC4zMjUsInN1YiI6IjY3OTE4NmMwZThiNjdmZjgzM2ZhNjM4OCIsInNjb3BlcyI6WyJhcGlfcmVhZCJdLCJ2ZXJzaW9uIjoxfQ.kWqK74FSN41PZO7_ENZelydTtX0u2g6dCkAW0vFs4jU';
export const TMDB_BASE_URL = 'https://api.themoviedb.org/3';
export const TMDB_IMAGE_BASE_URL = 'https://image.tmdb.org/t/p';

export const SERVERS = [
    { id: 1, name: 'Rakan' },
    { id: 2, name: 'Bard' },
    { id: 3, name: 'Xayah' },
    { id: 4, name: 'Ekko' },
    { id: 5, name: 'Ryze' },
    { id: 6, name: 'Azir' },
    { id: 7, name: 'Yasuo' },
    { id: 8, name: 'Zed' },
    { id: 9, name: 'Jinx' },
    { id: 10, name: 'Akali' },
    { id: 11, name: 'Sylas' },
    { id: 12, name: 'Yone' },
    { id: 13, name: 'Darius' },
    { id: 14, name: 'Poppy' },
    { id: 15, name: 'Nami' },
    { id: 16, name: 'Karma' },
    { id: 17, name: 'ArabHD' },
    { id: 18, name: 'FaselHD' },
    { id: 19, name: 'Prime' },
    { id: 20, name: 'GDrive' },
    { id: 21, name: 'Universe' },
    { id: 22, name: 'Ask4' },
    { id: 23, name: 'Solar' },
    { id: 24, name: 'C1ne' },
    { id: 25, name: 'TinyZone' },
    { id: 26, name: 'StreamM4U' },
    { id: 27, name: 'MovieJoy' },
    { id: 28, name: 'Riven' },
];

export const getServerUrl = (serverId: number, type: 'movie' | 'tv', id: string, season?: string, episode?: string): string => {
    switch (serverId) {
        // Movie URLs
        case 1: return type === 'movie' ? `https://vidsrc.cc/v3/embed/movie/${id}?autoPlay=false` : `https://vidsrc.cc/v3/embed/tv/${id}/${season}/${episode}?autoPlay=false`;
        case 2: return type === 'movie' ? `https://moviesapi.club/movie/${id}` : `https://moviesapi.club/tv/${id}-${season}-${episode}`;
        case 3: return type === 'movie' ? `https://vidsrc.me/embed/movie?tmdb=${id}` : `https://vidsrc.me/embed/tv?tmdb=${id}&season=${season}&episode=${episode}`;
        case 4: return type === 'movie' ? `https://player.videasy.net/movie/${id}` : `https://player.videasy.net/tv/${id}/${season}/${episode}?nextEpisode=true&episodeSelector=true`;
        case 5: return type === 'movie' ? `https://vidlink.pro/movie/${id}?title=true&poster=true&autoplay=false` : `https://vidlink.pro/tv/${id}/${season}/${episode}?title=true&poster=true&autoplay=false&nextbutton=true`;
        case 6: return type === 'movie' ? `https://embed.su/embed/movie/${id}` : `https://embed.su/embed/tv/${id}/${season}/${episode}`;
        case 7: return type === 'movie' ? `https://multiembed.mov/directstream.php?video_id=${id}&tmdb=1` : `https://multiembed.mov/directstream.php?video_id=${id}&tmdb=1&s=${season}&e=${episode}`;
        case 8: return type === 'movie' ? `https://vidsrc.to/embed/movie/${id}` : `https://vidsrc.to/embed/tv/${id}/${season}/${episode}`;
        case 9: return type === 'movie' ? `https://autoembed.co/movie/tmdb/${id}` : `https://autoembed.co/tv/tmdb/${id}-${season}-${episode}`;
        case 10: return type === 'movie' ? `https://www.2embed.cc/embed/${id}` : `https://www.2embed.cc/embedtv/${id}&s=${season}&e=${episode}`;
        case 11: return type === 'movie' ? `https://player.smashy.stream/movie/${id}` : `https://player.smashy.stream/tv/${id}?s=${season}&e=${episode}`;
        case 12: return type === 'movie' ? `https://embed.smashystream.com/playere.php?tmdb=${id}` : `https://embed.smashystream.com/playere.php?tmdb=${id}&season=${season}&episode=${episode}`;
        case 13: return type === 'movie' ? `https://vidsrc.vip/embed/movie/${id}` : `https://vidsrc.vip/embed/tv/${id}/${season}/${episode}`;
        case 14: return type === 'movie' ? `https://embed.warezcdn.net/filme/${id}` : `https://embed.warezcdn.net/serie/${id}/${season}/${episode}`;
        case 15: return type === 'movie' ? `https://api.whvx.net/embed/movie?id=${id}` : `https://api.whvx.net/embed/tv?id=${id}&s=${season}&e=${episode}`;
        case 16: return type === 'movie' ? `https://embed.primewire.li/movie?tmdb=${id}` : `https://embed.primewire.li/tv?tmdb=${id}&season=${season}&episode=${episode}`;
        case 17: return type === 'movie' ? `https://arabhd.net/embed/movie/${id}` : `https://arabhd.net/embed/tv/${id}/${season}-${episode}`;
        case 18: return type === 'movie' ? `https://faselhd.club/player?tmdb=${id}` : `https://faselhd.club/player?tmdb=${id}&s=${season}&e=${episode}`;
        case 19: return type === 'movie' ? `https://www.primewire.tf/embed/movie?tmdb=${id}` : `https://www.primewire.tf/embed/tv?tmdb=${id}&s=${season}&e=${episode}`;
        case 20: return type === 'movie' ? `https://database.gdriveplayer.us/player.php?tmdb=${id}` : `https://database.gdriveplayer.us/player.php?tmdb=${id}&season=${season}&episode=${episode}`;
        case 21: return type === 'movie' ? `https://movieuniverse.se/movie/${id}` : `https://movieuniverse.se/tv/${id}/${season}/${episode}`;
        case 22: return type === 'movie' ? `https://ask4movie.io/movie/${id}` : `https://ask4movie.io/tv/${id}/${season}/${episode}`;
        case 23: return type === 'movie' ? `https://solarmovie.pe/movie/${id}` : `https://solarmovie.pe/tv/${id}/${season}/${episode}`;
        case 24: return type === 'movie' ? `https://c1ne.co/movie/${id}` : `https://c1ne.co/tv/${id}/${season}/${episode}`;
        case 25: return type === 'movie' ? `https://tinyzonetv.to/movie/${id}` : `https://tinyzonetv.to/tv/${id}/${season}/${episode}`;
        case 26: return type === 'movie' ? `https://streamm4u.net/movie/${id}` : `https://streamm4u.net/tv/${id}/${season}/${episode}`;
        case 27: return type === 'movie' ? `https://moviejoy.to/movie/${id}` : `https://moviejoy.to/tv/${id}/${season}/${episode}`;
        case 28: return type === 'movie' ? `https://player.autoembed.cc/embed/movie/${id}` : `https://player.autoembed.cc/embed/tv/${id}/${season}/${episode}`;
        default: return `https://vidsrc.to/embed/movie/${id}`;
    }
};
