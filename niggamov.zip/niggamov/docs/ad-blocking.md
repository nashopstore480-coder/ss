## Ad-blocking Proxy and DNS-level Filtering

This app can benefit from network-level ad blocking to reduce popups, malicious scripts, and first-party ad injections from third-party video/content servers.

Two robust approaches:

1) DNS-level blocking with AdGuard Home or Pi-hole
2) Reverse proxy filtering with NGINX (strip ad scripts and block ad endpoints)

---

### 1) DNS-level Blocking (AdGuard Home / Pi-hole)

- What it does: Blocks known ad and tracking domains before any HTTP request leaves your network.
- Pros: Works for all devices; minimal maintenance after initial setup.
- Cons: Cannot block first-party ads served from the same domain as the site.

Docker Compose examples (pick one):

```yaml
# AdGuard Home
version: "3.7"
services:
  adguardhome:
    image: adguard/adguardhome:latest
    container_name: adguardhome
    ports:
      - "53:53/tcp"
      - "53:53/udp"
      - "3000:3000/tcp"   # initial setup UI
      - "80:80/tcp"
      - "443:443/tcp"
    volumes:
      - ./adguard/work:/opt/adguardhome/work
      - ./adguard/conf:/opt/adguardhome/conf
    restart: unless-stopped
```

```yaml
# Pi-hole
version: "3.7"
services:
  pihole:
    container_name: pihole
    image: pihole/pihole:latest
    environment:
      TZ: "UTC"
      WEBPASSWORD: "changeme"
    ports:
      - "53:53/tcp"
      - "53:53/udp"
      - "8080:80/tcp"   # admin UI on :8080
    volumes:
      - ./pihole/etc-pihole:/etc/pihole
      - ./pihole/etc-dnsmasq.d:/etc/dnsmasq.d
    restart: unless-stopped
```

Steps:
1. Deploy one of the above Docker stacks on your server.
2. Complete the web setup and add quality blocklists (e.g., OISD, 1Hosts, HaGeZi variants).
3. Point your router or server DNS to the IP of the DNS blocker.
4. Verify ad/tracker requests are blocked using DevTools → Network.

Security tips:
- Keep port 53 restricted to your private network; avoid exposing to the public internet.
- Backup the configuration volumes.

---

### 2) Reverse Proxy Filtering (NGINX)

- What it does: Proxies traffic to the upstream site and strips ad scripts/requests from responses, including some first-party ads.
- Pros: Can surgically remove inline scripts and block same-domain ad endpoints.
- Cons: Requires ongoing tuning as providers change markup; test thoroughly.

Example NGINX server (adjust domains and paths to your upstream):

```nginx
# /etc/nginx/conf.d/site.conf
server {
  listen 80;
  server_name your-proxy.example.com;

  # Hardened baseline CSP (tune per app needs)
  add_header Content-Security-Policy "default-src 'self' blob: data:; script-src 'self'; connect-src *; img-src * data: blob:; media-src * blob:; frame-src *;" always;

  location / {
    proxy_pass https://origin.example;         # upstream site or content server
    proxy_set_header Host origin.example;
    proxy_set_header X-Forwarded-For $remote_addr;
    proxy_set_header X-Forwarded-Proto $scheme;

    proxy_buffering off;
    proxy_request_buffering off;
    proxy_hide_header Content-Security-Policy;

    # Requires ngx_http_sub_module
    sub_filter_once off;
    sub_filter_types text/html application/javascript;

    # Neutralize common ad providers / markers
    sub_filter '<script src="https://ads.' '<!-- removed ad script -->';
    sub_filter 'googletagmanager.com' 'blocked.local';
    sub_filter 'googlesyndication.com' 'blocked.local';
    sub_filter 'doubleclick.net' 'blocked.local';
    sub_filter 'taboola.com' 'blocked.local';
    sub_filter 'outbrain.com' 'blocked.local';
    sub_filter 'u002Fads' 'u002Fvoid';

    # Block common ad endpoints by path
    location ~* /(ads?|adservice|advert|doubleclick|prebid|bidder|tracking|pixel) {
      return 403;
    }

    # Keep HLS/DASH streaming stable
    location ~* \.(m3u8|ts|mpd|m4s)$ {
      proxy_pass https://origin.example;
      proxy_set_header Host origin.example;
      proxy_buffering off;
      proxy_request_buffering off;
      add_header Cache-Control "no-store";
    }
  }
}
```

Block well-known ad hosts at the vhost level:

```nginx
map $http_host $is_ad_host {
  default 0;
  ~*(doubleclick\.net|googlesyndication\.com|adservice\.google\.com|taboola\.com|outbrain\.com) 1;
}

server {
  listen 80 default_server;
  if ($is_ad_host) { return 444; }
}
```

Production tips:
- Use HTTPS with valid certificates (e.g., certbot).
- Confirm your NGINX build includes `ngx_http_sub_module`. Consider `headers-more` for finer header control.
- Monitor for layout breakage after upstream changes and adjust `sub_filter` patterns accordingly.

---

### Integrating with this app

- If you centralize endpoints in the client, point them to the proxy domain (e.g., `your-proxy.example.com`).
- Continue using client-side protections (`services/adBlockService.ts`) as a secondary layer.
- For full-site proxying, simply browse via the proxy domain.

---

### Quick Checklist

- DNS-level: deploy AdGuard/Pi-hole → add blocklists → point DNS → verify blocks.
- Reverse proxy: deploy NGINX → tune `sub_filter` to your upstream → verify site and streaming.



