import React, { useState, useEffect, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import { useDebounce } from '../hooks/useDebounce';
import { searchMedia } from '../services/tmdbService';
import { SearchResult } from '../types';
import { TMDB_IMAGE_BASE_URL } from '../constants';
import { SearchIcon } from './icons/SearchIcon';
import Loader from './Loader';

const SearchBar: React.FC = () => {
  const [query, setQuery] = useState('');
  const [results, setResults] = useState<SearchResult[]>([]);
  const [loading, setLoading] = useState(false);
  const [showResults, setShowResults] = useState(false);
  const [activeIndex, setActiveIndex] = useState(-1);
  const debouncedQuery = useDebounce(query, 300);
  const navigate = useNavigate();
  const searchContainerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (searchContainerRef.current && !searchContainerRef.current.contains(event.target as Node)) {
        setShowResults(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  useEffect(() => {
    if (debouncedQuery.length > 1) {
      setLoading(true);
      setShowResults(true);
      setActiveIndex(-1);
      searchMedia(debouncedQuery)
        .then(data => setResults(data))
        .catch(err => console.error(err))
        .finally(() => setLoading(false));
    } else {
      setResults([]);
      setShowResults(false);
    }
  }, [debouncedQuery]);

  const handleResultClick = (result: SearchResult) => {
    const params = new URLSearchParams();
    params.set('type', result.media_type);
    params.set('id', result.id.toString());
    if (result.media_type === 'tv') {
        params.set('s', '1');
        params.set('e', '1');
    }
    navigate(`/watch?${params.toString()}`);
    setQuery('');
    setShowResults(false);
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'ArrowDown') {
      e.preventDefault();
      setActiveIndex(prev => (prev < results.length - 1 ? prev + 1 : prev));
    } else if (e.key === 'ArrowUp') {
      e.preventDefault();
      setActiveIndex(prev => (prev > 0 ? prev - 1 : 0));
    } else if (e.key === 'Enter' && activeIndex >= 0) {
      handleResultClick(results[activeIndex]);
    } else if (e.key === 'Escape') {
      setShowResults(false);
    }
  };

  const movieResults = results.filter(r => r.media_type === 'movie');
  const tvResults = results.filter(r => r.media_type === 'tv');

  return (
    <div className="relative max-w-xl mx-auto" ref={searchContainerRef}>
      <div className="relative">
        <input
          type="text"
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          onFocus={() => query.length > 1 && setShowResults(true)}
          onKeyDown={handleKeyDown}
          placeholder="Search for a movie or TV show..."
          className="w-full pl-12 pr-10 py-3 bg-white/10 text-white placeholder-gray-400 border-2 border-transparent focus:border-indigo-500 focus:ring-0 focus:outline-none rounded-full backdrop-blur-sm transition-all"
        />
        <div className="absolute left-4 top-1/2 -translate-y-1/2">
          <SearchIcon className="w-6 h-6 text-gray-400" />
        </div>
        {loading && (
          <div className="absolute right-4 top-1/2 -translate-y-1/2">
              <Loader />
          </div>
        )}
      </div>

      <div className={`absolute top-full mt-2 w-full bg-gray-800/80 backdrop-blur-lg rounded-2xl overflow-hidden shadow-2xl border border-white/10 transform transition-all duration-200 ease-out origin-top
        ${showResults && !loading
            ? 'opacity-100 scale-100 visible'
            : 'opacity-0 scale-95 invisible'}`
      }>
          {results.length === 0 && debouncedQuery.length > 1 ? (
            <div className="p-4 text-center text-gray-400">No results found for "{debouncedQuery}".</div>
          ) : (
            <ul className="max-h-[60vh] overflow-y-auto">
              {movieResults.length > 0 && <li className="px-4 pt-3 pb-1 font-bold text-indigo-300 text-sm uppercase">Movies</li>}
              {movieResults.map((result, index) => (
                <SearchResultItem key={result.id} result={result} isActive={activeIndex === index} onClick={handleResultClick} onMouseEnter={() => setActiveIndex(index)} />
              ))}
              {tvResults.length > 0 && <li className="px-4 pt-3 pb-1 font-bold text-indigo-300 text-sm uppercase">TV Shows</li>}
              {tvResults.map((result, index) => (
                <SearchResultItem key={result.id} result={result} isActive={activeIndex === movieResults.length + index} onClick={handleResultClick} onMouseEnter={() => setActiveIndex(movieResults.length + index)} />
              ))}
            </ul>
          )}
      </div>
    </div>
  );
};

interface SearchResultItemProps {
  result: SearchResult;
  isActive: boolean;
  onClick: (result: SearchResult) => void;
  onMouseEnter: () => void;
}

const SearchResultItem: React.FC<SearchResultItemProps> = ({ result, isActive, onClick, onMouseEnter }) => (
  <li
    onClick={() => onClick(result)}
    onMouseEnter={onMouseEnter}
    className={`flex items-center p-3 cursor-pointer transition-colors ${isActive ? 'bg-indigo-500/30' : 'hover:bg-indigo-500/20'}`}
  >
    <img
      src={result.poster_path ? `${TMDB_IMAGE_BASE_URL}/w92${result.poster_path}` : 'https://via.placeholder.com/92x138.png?text=No+Image'}
      alt={result.title || result.name}
      className="w-12 h-auto rounded-md mr-4 bg-gray-700 shrink-0"
    />
    <div className="flex-grow overflow-hidden">
      <p className="font-semibold text-white truncate">{result.title || result.name}</p>
      <div className="flex items-center gap-2 text-sm text-gray-400 mt-1">
        <span>{(result.release_date || result.first_air_date || '').split('-')[0]}</span>
        <span className={`px-2 py-0.5 rounded-full text-xs font-semibold leading-none ${
            result.media_type === 'movie' 
            ? 'bg-indigo-500/20 text-indigo-300' 
            : 'bg-teal-500/20 text-teal-300'
        }`}>
            {result.media_type === 'movie' ? 'Movie' : 'TV Show'}
        </span>
      </div>
    </div>
  </li>
);


export default SearchBar;