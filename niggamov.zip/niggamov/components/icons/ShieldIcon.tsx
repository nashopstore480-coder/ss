import React from 'react';

export const ShieldIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M12 21.75c4.256-1.282 7.5-6.006 7.5-11.25V5.25L12 3 4.5 5.25v5.25c0 5.244 3.244 9.968 7.5 11.25z" />
    </svg>
);
