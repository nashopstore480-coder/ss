import React, { useEffect, useState } from 'react';

const DISMISS_KEY = 'cinesphere_secure_dns_banner_dismissed_v1';

const SecureDnsBanner: React.FC = () => {
    const [visible, setVisible] = useState(false);

    useEffect(() => {
        try {
            const dismissed = localStorage.getItem(DISMISS_KEY);
            setVisible(dismissed !== 'true');
        } catch {
            setVisible(true);
        }
    }, []);

    const dismiss = () => {
        try { localStorage.setItem(DISMISS_KEY, 'true'); } catch {}
        setVisible(false);
    };

    if (!visible) return null;

    return (
        <div className="container mx-auto px-4 pt-4">
            <div className="rounded-lg border border-white/10 bg-indigo-600/10 text-indigo-200 p-4 flex flex-col md:flex-row md:items-center md:justify-between gap-3">
                <div className="space-y-1">
                    <div className="font-bold text-indigo-300">Improve ad blocking with Secure DNS</div>
                    <div className="text-sm text-indigo-200/90">
                        Chrome/Edge: Settings → Privacy → Use secure DNS → Custom → <code>https://dns.adguard-dns.com/dns-query</code>
                    </div>
                    <div className="text-sm text-indigo-200/90">
                        Android: Settings → Network → Private DNS → <code>dns.adguard-dns.com</code>
                    </div>
                    <a
                      className="text-xs underline text-indigo-300 hover:text-indigo-200"
                      href="https://adguard.com/en/welcome.html"
                      target="_blank"
                      rel="noreferrer"
                    >Learn more about AdGuard</a>
                </div>
                <button
                  onClick={dismiss}
                  className="self-start md:self-auto px-3 py-1.5 rounded-md bg-white/10 hover:bg-white/20 text-indigo-100 text-sm"
                >Dismiss</button>
            </div>
        </div>
    );
};

export default SecureDnsBanner;


