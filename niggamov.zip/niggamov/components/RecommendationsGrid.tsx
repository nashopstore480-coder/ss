import React from 'react';
import { Media } from '../types';
import MediaCard from './MediaCard';

interface RecommendationsGridProps {
    recommendations: Media[];
}

const RecommendationsGrid: React.FC<RecommendationsGridProps> = ({ recommendations }) => {
    return (
        <div>
            <h2 className="text-2xl font-bold mb-4 text-indigo-300">More Like This</h2>
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-4">
                {recommendations.map(media => (
                    <MediaCard key={media.id} media={media} media_type={media.media_type || 'movie'}/>
                ))}
            </div>
        </div>
    );
};

export default RecommendationsGrid;
