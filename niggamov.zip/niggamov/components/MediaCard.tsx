import React from 'react';
import { Link } from 'react-router-dom';
import { Media } from '../types';
import { TMDB_IMAGE_BASE_URL } from '../constants';
import { StarIcon } from './icons/StarIcon';

interface MediaCardProps {
  media: Media;
  media_type?: 'movie' | 'tv';
}

const MediaCard: React.FC<MediaCardProps> = ({ media, media_type }) => {
  const type = media.media_type || media_type;

  if (!type) {
    console.warn("MediaCard: media object is missing media_type", media);
    return null; // Don't render if we can't determine the type
  }

  const title = media.title || media.name || 'No Title';
  const linkTo = `/watch?type=${type}&id=${media.id}${type === 'tv' ? '&s=1&e=1' : ''}`;

  return (
    <Link to={linkTo} className="group relative block overflow-hidden rounded-lg shadow-lg bg-gray-800">
      <img
        src={media.poster_path ? `${TMDB_IMAGE_BASE_URL}/w500${media.poster_path}` : 'https://via.placeholder.com/500x750.png?text=No+Image'}
        alt={title}
        className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-105"
        loading="lazy"
      />
      <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/0 to-black/30"></div>
      
      {media.vote_average > 0 && (
          <div className="absolute top-2 right-2 flex items-center gap-1 bg-black/50 text-white text-xs font-bold px-2 py-1 rounded-full backdrop-blur-sm">
            <StarIcon className="w-3 h-3 text-yellow-400" />
            {media.vote_average.toFixed(1)}
          </div>
      )}

      <div className="absolute bottom-0 left-0 p-3 w-full">
        <h3 className="text-white font-bold text-md leading-tight group-hover:text-indigo-300 transition-colors line-clamp-2">{title}</h3>
      </div>
    </Link>
  );
};

export default MediaCard;