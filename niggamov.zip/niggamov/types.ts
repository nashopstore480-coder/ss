export interface Genre {
  id: number;
  name: string;
}

export interface Cast {
  id: number;
  name: string;
  character: string;
  profile_path: string | null;
}

export interface Credits {
  cast: Cast[];
}

export interface Media {
  id: number;
  title?: string;
  name?: string;
  poster_path: string | null;
  backdrop_path: string | null;
  overview: string;
  release_date?: string;
  first_air_date?: string;
  vote_average: number;
  media_type?: 'movie' | 'tv';
  genres?: Genre[];
  credits?: Credits;
  recommendations?: {
    results: Media[];
  }
}

export interface Movie extends Media {
  original_title: string;
}

export interface TVShow extends Media {
  original_name: string;
  seasons: {
    id: number;
    season_number: number;
    episode_count: number;
  }[];
}

export interface TVSeasonDetails {
  name: string;
  air_date: string;
  poster_path: string;
  episodes: {
    id: number;
    name: string;
    episode_number: number;
    season_number: number;
    air_date: string;
    runtime: number;
    still_path: string;
  }[];
}

export interface SearchResult extends Media {
  media_type: 'movie' | 'tv';
}