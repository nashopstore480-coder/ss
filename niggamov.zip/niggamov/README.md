<div align="center">
<img width="1200" height="475" alt="GHBanner" src="https://github.com/user-attachments/assets/0aa67016-6eaf-458a-adb2-6e31a0763ed6" />
</div>

# Run and deploy the app

This contains everything you need to run your app locally.

This project is a React + TypeScript app built with Vite.

## Run Locally

**Prerequisites:**  Node.js


1. Install dependencies:
   `npm install`
2. Run the app:
   `npm run dev`

## Ad-blocking Proxy (Optional)

If your content servers inject ads, consider a network-level solution:

- DNS-level blocking with AdGuard Home or Pi-hole
- Reverse proxy filtering with NGINX to strip ad scripts and block endpoints

See detailed setup and examples in [docs/ad-blocking.md](docs/ad-blocking.md).
