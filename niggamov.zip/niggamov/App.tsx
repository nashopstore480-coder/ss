import React, { useState } from 'react';
import { HashRouter, Routes, Route } from 'react-router-dom';
import HomePage from './pages/HomePage';
import WatchPage from './pages/WatchPage';
import Header from './components/Header';

const App: React.FC = () => {
  // AI features removed

  return (
    <HashRouter>
      <div className="bg-gray-900 text-white min-h-screen">
        <div className="absolute top-0 left-0 w-full h-full bg-gradient-to-br from-indigo-900/30 via-gray-900 to-black z-0"></div>
        <div className="relative z-10">
          <Header />
          <main className="pt-20">
            <Routes>
              <Route path="/" element={<HomePage />} />
              <Route path="/watch" element={<WatchPage openAiModal={() => {}} />} />
            </Routes>
          </main>
          {/* AI UI removed */}
        </div>
      </div>
    </HashRouter>
  );
};

export default App;
