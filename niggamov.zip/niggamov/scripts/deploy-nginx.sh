#!/usr/bin/env bash
set -euo pipefail

# Deploy a Vite + React SPA to Nginx on Ubuntu without moving the dist folder.
# - Builds the project
# - Keeps dist in the project directory
# - Configures Nginx to serve directly from that dist path
# - Reloads Nginx
#
# Usage:
#   sudo bash scripts/deploy-nginx.sh [DOMAIN]
# Example:
#   sudo bash scripts/deploy-nginx.sh niggamov.site

if [[ ${EUID:-$(id -u)} -ne 0 ]]; then
  echo "Please run as root (use: sudo bash scripts/deploy-nginx.sh [DOMAIN])" >&2
  exit 1
fi

REPO_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")"/.. && pwd)"
DIST_DIR="$REPO_DIR/dist"
DOMAIN="niggamov.site"  # default server_name is '_' if not provided
SITE_NAME="niggamov"
NGINX_AVAILABLE="/etc/nginx/sites-available/${SITE_NAME}.conf"
NGINX_ENABLED="/etc/nginx/sites-enabled/${SITE_NAME}.conf"

echo "[1/5] Ensuring prerequisites..."
command -v node >/dev/null 2>&1 || { echo "Node.js is required" >&2; exit 1; }
command -v npm >/dev/null 2>&1 || { echo "npm is required" >&2; exit 1; }
command -v nginx >/dev/null 2>&1 || { echo "nginx is required (apt install nginx)" >&2; exit 1; }

echo "[2/5] Installing deps and building..."
cd "$REPO_DIR"
if [[ -f package-lock.json ]]; then
  npm ci
else
  npm install
fi
npm run build

if [[ ! -d "$DIST_DIR" ]]; then
  echo "Build failed: dist directory not found at $DIST_DIR" >&2
  exit 1
fi

echo "[3/5] Setting read permissions for Nginx..."
# Allow nginx (www-data) to read the build output in place
find "$DIST_DIR" -type d -exec chmod a+rx {} \;
find "$DIST_DIR" -type f -exec chmod a+r {} \;

echo "[4/5] Writing Nginx site config..."
cat > "$NGINX_AVAILABLE" <<EOF
server {
  listen 80;
  server_name ${DOMAIN};

  # Serve SPA directly from the built dist folder
  root ${DIST_DIR};
  index index.html;

  access_log /var/log/nginx/${SITE_NAME}.access.log;
  error_log  /var/log/nginx/${SITE_NAME}.error.log;

  # Cache static assets more aggressively
  location /assets/ {
    expires 7d;
    add_header Cache-Control "public, max-age=604800, immutable";
  }

  # SPA fallback to index.html
  location / {
    try_files $uri $uri/ /index.html;
  }
}
EOF

ln -sf "$NGINX_AVAILABLE" "$NGINX_ENABLED"

# Optionally disable the default site if present
if [[ -e /etc/nginx/sites-enabled/default ]]; then
  rm -f /etc/nginx/sites-enabled/default || true
fi

echo "[5/5] Testing and reloading Nginx..."
nginx -t
systemctl reload nginx

echo "Deployment complete."
echo "- Domain: ${DOMAIN}"
echo "- Serving from: ${DIST_DIR}"
echo "- Config: ${NGINX_AVAILABLE}"

