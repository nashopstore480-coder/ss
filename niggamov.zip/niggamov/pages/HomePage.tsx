import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { getPopularMovies, getPopularTVShows, getTopRatedMovies, getNowPlayingMovies, getRandomPopularMovie } from '../services/tmdbService';
import { getViewingHistory } from '../services/historyService';
import { Movie, TVShow, Media } from '../types';
import MediaCard from '../components/MediaCard';
import Loader from '../components/Loader';
import SearchBar from '../components/SearchBar';
import { TMDB_IMAGE_BASE_URL } from '../constants';
import { WandIcon } from '../components/icons/WandIcon';
import SecureDnsBanner from '../components/SecureDnsBanner';

const HomePage: React.FC = () => {
  const [popularMovies, setPopularMovies] = useState<Movie[]>([]);
  const [popularTV, setPopularTV] = useState<TVShow[]>([]);
  const [topRatedMovies, setTopRatedMovies] = useState<Movie[]>([]);
  const [nowPlaying, setNowPlaying] = useState<Movie[]>([]);
  const [continueWatching, setContinueWatching] = useState<Media[]>([]);
  const [loading, setLoading] = useState(true);
  const [heroMovie, setHeroMovie] = useState<Movie | null>(null);
  const navigate = useNavigate();

  useEffect(() => {
    const fetchAllMedia = async () => {
      try {
        const [movies, tvShows, topRated, playing] = await Promise.all([
          getPopularMovies(),
          getPopularTVShows(),
          getTopRatedMovies(),
          getNowPlayingMovies()
        ]);
        
        setPopularMovies(movies);
        setPopularTV(tvShows);
        setTopRatedMovies(topRated);
        setNowPlaying(playing);
        setContinueWatching(getViewingHistory());

        if (movies.length > 0) {
          setHeroMovie(movies[Math.floor(Math.random() * Math.min(movies.length, 10))]);
        }
      } catch (error) {
        console.error("Failed to fetch media:", error);
      } finally {
        setLoading(false);
      }
    };

    fetchAllMedia();
  }, []);

  const handleSurpriseMe = async () => {
    try {
        const randomMovie = await getRandomPopularMovie();
        if(randomMovie) {
            navigate(`/watch?type=movie&id=${randomMovie.id}`);
        }
    } catch (error) {
        console.error("Failed to fetch random movie:", error);
    }
  }

  const heroStyle = heroMovie?.backdrop_path ? {
    backgroundImage: `linear-gradient(to top, rgb(15 23 42 / 1), rgb(15 23 42 / 0.7) 30%, rgb(15 23 42 / 1) 100%), url(${TMDB_IMAGE_BASE_URL}/w1280${heroMovie.backdrop_path})`
  } : {};

  return (
    <div className="-mt-20">
      <SecureDnsBanner />
      <section 
        className="h-[70vh] md:h-[90vh] flex flex-col items-center justify-center text-center p-4 bg-cover bg-center bg-no-repeat transition-all duration-1000"
        style={heroStyle}
      >
        <div className="max-w-4xl px-4">
            {heroMovie && (
                <div className="mb-8 animate-fade-in-up">
                    <h1 className="text-4xl md:text-7xl font-extrabold text-white drop-shadow-xl mb-4">
                        {heroMovie.title}
                    </h1>
                    <p className="text-md md:text-lg text-gray-300 drop-shadow-lg max-w-2xl mx-auto line-clamp-3">
                        {heroMovie.overview}
                    </p>
                    <button 
                      onClick={() => navigate(`/watch?type=movie&id=${heroMovie.id}`)}
                      className="mt-6 px-8 py-3 bg-indigo-600 text-white font-bold rounded-full hover:bg-indigo-500 transition-transform hover:scale-105 shadow-lg"
                    >
                      Watch Now
                    </button>
                </div>
            )}
            <SearchBar />
            <button 
                onClick={handleSurpriseMe}
                className="mt-4 flex items-center gap-2 px-5 py-2 bg-white/10 text-white font-semibold rounded-full hover:bg-white/20 transition-all backdrop-blur-sm"
            >
                <WandIcon className="w-5 h-5" />
                Surprise Me!
            </button>
        </div>
      </section>

      {loading ? (
        <div className="flex justify-center items-center h-64">
          <Loader />
        </div>
      ) : (
        <div className="space-y-16 container mx-auto px-4 py-12">
            {continueWatching.length > 0 && (
                <MediaSection title="Continue Watching" items={continueWatching} />
            )}
            <MediaSection title="Popular Movies" items={popularMovies} mediaType="movie" />
            <MediaSection title="Popular TV Shows" items={popularTV} mediaType="tv" />
            <MediaSection title="Top Rated Movies" items={topRatedMovies} mediaType="movie" />
            <MediaSection title="Now Playing in Theaters" items={nowPlaying} mediaType="movie" />
        </div>
      )}
    </div>
  );
};

interface MediaSectionProps {
    title: string;
    items: Media[];
    mediaType?: 'movie' | 'tv';
}

const MediaSection: React.FC<MediaSectionProps> = ({ title, items, mediaType }) => (
    <section>
        <h2 className="text-3xl font-bold mb-6 text-indigo-300">{title}</h2>
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-4 md:gap-6">
            {items.map(item => (
              <MediaCard key={`${title}-${item.id}`} media={item} media_type={mediaType} />
            ))}
        </div>
    </section>
);

export default HomePage;