const INTERACTION_SHIELD_KEY = 'niggamov_interactionShieldEnabled';

/**
 * Retrieves the enabled state of the Interaction Shield from localStorage.
 * @returns {boolean} The enabled state, defaulting to true for better ad protection.
 */
export const getInteractionShieldEnabled = (): boolean => {
    try {
        const value = localStorage.getItem(INTERACTION_SHIELD_KEY);
        // Default to true if the setting doesn't exist yet
        return value === null ? true : value === 'true';
    } catch (error) {
        console.error("Failed to get Interaction Shield setting:", error);
        return true;
    }
};

/**
 * Sets the enabled state of the Interaction Shield in localStorage.
 * @param {boolean} isEnabled - The new state to set.
 */
export const setInteractionShieldEnabled = (isEnabled: boolean): void => {
    try {
        localStorage.setItem(INTERACTION_SHIELD_KEY, JSON.stringify(isEnabled));
    } catch (error) {
        console.error("Failed to set Interaction Shield setting:", error);
    }
};
