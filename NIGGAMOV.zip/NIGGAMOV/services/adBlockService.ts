/**
 * Advanced Ad Blocking Service for niggamov
 * Prevents unwanted popups, redirects, and ad interactions
 */

const BLACKLISTED_SERVERS_KEY = 'niggamov_blacklistedServers';
const AD_BLOCK_SETTINGS_KEY = 'niggamov_adBlockSettings';

interface AdBlockSettings {
  enabled: boolean;
  blockPopups: boolean;
  blockRedirects: boolean;
  blockAutoPlay: boolean;
  aggressiveMode: boolean;
}

const defaultSettings: AdBlockSettings = {
  enabled: true,
  blockPopups: true,
  blockRedirects: true,
  blockAutoPlay: false,
  aggressiveMode: false
};

/**
 * Get current ad block settings
 */
export const getAdBlockSettings = (): AdBlockSettings => {
  try {
    const settings = localStorage.getItem(AD_BLOCK_SETTINGS_KEY);
    return settings ? { ...defaultSettings, ...JSON.parse(settings) } : defaultSettings;
  } catch (error) {
    console.error("Failed to get ad block settings:", error);
    return defaultSettings;
  }
};

/**
 * Update ad block settings
 */
export const setAdBlockSettings = (settings: Partial<AdBlockSettings>): void => {
  try {
    const currentSettings = getAdBlockSettings();
    const newSettings = { ...currentSettings, ...settings };
    localStorage.setItem(AD_BLOCK_SETTINGS_KEY, JSON.stringify(newSettings));
  } catch (error) {
    console.error("Failed to set ad block settings:", error);
  }
};

/**
 * Get blacklisted servers
 */
export const getBlacklistedServers = (): number[] => {
  try {
    const blacklist = localStorage.getItem(BLACKLISTED_SERVERS_KEY);
    return blacklist ? JSON.parse(blacklist) : [];
  } catch (error) {
    console.error("Failed to get blacklisted servers:", error);
    return [];
  }
};

/**
 * Add server to blacklist
 */
export const blacklistServer = (serverId: number): void => {
  try {
    const blacklist = getBlacklistedServers();
    if (!blacklist.includes(serverId)) {
      blacklist.push(serverId);
      localStorage.setItem(BLACKLISTED_SERVERS_KEY, JSON.stringify(blacklist));
    }
  } catch (error) {
    console.error("Failed to blacklist server:", error);
  }
};

/**
 * Remove server from blacklist
 */
export const whitelistServer = (serverId: number): void => {
  try {
    const blacklist = getBlacklistedServers();
    const filtered = blacklist.filter(id => id !== serverId);
    localStorage.setItem(BLACKLISTED_SERVERS_KEY, JSON.stringify(filtered));
  } catch (error) {
    console.error("Failed to whitelist server:", error);
  }
};

/**
 * Check if server is blacklisted
 */
export const isServerBlacklisted = (serverId: number): boolean => {
  return getBlacklistedServers().includes(serverId);
};

/**
 * Create a sandboxed iframe with ad blocking
 */
export const createAdBlockedIframe = (
  src: string,
  container: HTMLElement,
  settings: AdBlockSettings = getAdBlockSettings()
): HTMLIFrameElement => {
  const iframe = document.createElement('iframe');
  
  // Set iframe attributes
  iframe.src = src;
  iframe.title = "Media Player";
  iframe.allow = "autoplay; encrypted-media; picture-in-picture";
  iframe.allowFullscreen = true;
  iframe.className = "w-full h-full";
  
  // Sandbox attributes to prevent unwanted behavior
  const sandboxAttrs = [
    'allow-scripts',
    'allow-same-origin',
    'allow-forms',
    'allow-popups-to-escape-sandbox',
    'allow-top-navigation-by-user-activation'
  ];
  
  if (settings.blockPopups) {
    // Remove popup permissions
    const filteredAttrs = sandboxAttrs.filter(attr => 
      !attr.includes('popups') && !attr.includes('navigation')
    );
    iframe.sandbox.value = filteredAttrs.join(' ');
  } else {
    iframe.sandbox.value = sandboxAttrs.join(' ');
  }
  
  // Add referrer policy to prevent tracking
  iframe.referrerPolicy = 'no-referrer';
  
  // Add CSP-like attributes
  iframe.setAttribute('data-ad-blocked', 'true');
  
  // Intercept and block unwanted requests
  if (settings.aggressiveMode) {
    iframe.onload = () => {
      try {
        // Try to inject ad blocking script into iframe
        const iframeDoc = iframe.contentDocument || iframe.contentWindow?.document;
        if (iframeDoc) {
          const script = iframeDoc.createElement('script');
          script.textContent = `
            // Block common ad domains
            const blockedDomains = [
              'doubleclick.net', 'googlesyndication.com', 'googleadservices.com',
              'amazon-adsystem.com', 'adsystem.amazon.com', 'facebook.com/tr',
              'outbrain.com', 'taboola.com', 'ads.yahoo.com', 'adsystem.amazon.com'
            ];
            
            // Override window.open to block popups
            const originalOpen = window.open;
            window.open = function(url, name, specs) {
              console.log('Blocked popup attempt:', url);
              return null;
            };
            
            // Block redirects
            const originalAssign = window.location.assign;
            window.location.assign = function(url) {
              console.log('Blocked redirect attempt:', url);
            };
            
            // Block common ad elements
            const observer = new MutationObserver(function(mutations) {
              mutations.forEach(function(mutation) {
                mutation.addedNodes.forEach(function(node) {
                  if (node.nodeType === 1) { // Element node
                    const element = node;
                    if (element.tagName === 'IFRAME' || element.tagName === 'SCRIPT') {
                      const src = element.src || element.getAttribute('src');
                      if (src && blockedDomains.some(domain => src.includes(domain))) {
                        element.remove();
                        console.log('Blocked ad element:', src);
                      }
                    }
                  }
                });
              });
            });
            
            observer.observe(document.body, { childList: true, subtree: true });
          `;
          iframeDoc.head.appendChild(script);
        }
      } catch (error) {
        // Cross-origin restrictions - this is expected for most iframes
        console.log('Cannot inject ad blocking script due to CORS restrictions');
      }
    };
  }
  
  return iframe;
};

/**
 * Enhanced interaction shield that prevents clicks from reaching the iframe
 */
export const createInteractionShield = (
  container: HTMLElement,
  onActivate: () => void
): HTMLElement => {
  const shield = document.createElement('div');
  shield.className = 'player-overlay';
  shield.setAttribute('aria-label', 'Activate Player');
  shield.setAttribute('role', 'button');
  shield.setAttribute('tabindex', '0');
  
  // Create activation button
  const button = document.createElement('div');
  button.className = 'player-activation-button';
  
  const playIcon = document.createElement('div');
  playIcon.innerHTML = `
    <svg class="w-8 h-8 text-white" fill="currentColor" viewBox="0 0 24 24">
      <path d="M8 5v14l11-7z"/>
    </svg>
  `;
  button.appendChild(playIcon);
  
  // Create activation text
  const text = document.createElement('div');
  text.className = 'player-activation-text';
  text.textContent = 'Click to activate player';
  
  shield.appendChild(button);
  shield.appendChild(text);
  
  // Add click handler
  const handleActivation = (e: Event) => {
    e.preventDefault();
    e.stopPropagation();
    onActivate();
  };
  
  shield.addEventListener('click', handleActivation);
  shield.addEventListener('keydown', (e) => {
    if (e.key === 'Enter' || e.key === ' ') {
      handleActivation(e);
    }
  });
  
  return shield;
};

/**
 * Monitor iframe for suspicious activity
 */
export const monitorIframeActivity = (iframe: HTMLIFrameElement): void => {
  const settings = getAdBlockSettings();
  
  if (!settings.enabled) return;
  
  // Monitor for popup attempts
  const originalOpen = window.open;
  window.open = function(url: string, name?: string, specs?: string) {
    if (settings.blockPopups) {
      console.log('🚫 Blocked popup attempt:', url);
      return null;
    }
    return originalOpen.call(window, url, name, specs);
  };
  
  // Monitor for redirect attempts (only if assign is writable)
  try {
    const desc = Object.getOwnPropertyDescriptor(window.location.__proto__ || Location.prototype, 'assign');
    const isWritable = !desc || !!desc.writable || !!desc.set;
    if (isWritable) {
      const originalAssign = window.location.assign.bind(window.location);
      (window.location as any).assign = function(url: string) {
        if (settings.blockRedirects) {
          console.log('🚫 Blocked redirect attempt:', url);
          return;
        }
        return originalAssign(url);
      };
    }
  } catch {
    // In some browsers Location.assign is readonly; skip overriding
  }
  
  // Monitor iframe focus changes (potential redirect indicator)
  iframe.addEventListener('load', () => {
    try {
      const iframeWindow = iframe.contentWindow;
      if (iframeWindow) {
        // Monitor for focus changes that might indicate redirects
        let lastUrl = iframe.src;
        setInterval(() => {
          try {
            if (iframeWindow.location.href !== lastUrl) {
              console.log('🚫 Detected iframe redirect attempt');
              if (settings.blockRedirects) {
                iframe.src = lastUrl; // Reset to original URL
              }
            }
          } catch (error) {
            // Cross-origin restrictions - this is expected
          }
        }, 1000);
      }
    } catch (error) {
      // Cross-origin restrictions - this is expected
    }
  });
};

/**
 * Get server quality score based on ad reports
 */
export const getServerQualityScore = (serverId: number): number => {
  const blacklistedServers = getBlacklistedServers();
  if (blacklistedServers.includes(serverId)) {
    return 0; // Blacklisted
  }
  
  // You can implement more sophisticated scoring here
  // For now, return a default score
  return 100;
};
