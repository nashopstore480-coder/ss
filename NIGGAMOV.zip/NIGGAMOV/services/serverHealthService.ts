export type ServerHealth = {
    serverId: number;
    latencyMs: number | null;
    ok: boolean;
    checkedAt: number;
};

const HEALTH_CACHE_KEY = 'niggamov_server_health_v1';
const TIMEOUT_MS = 4000;
const STALE_AFTER_MS = 5 * 60 * 1000;

const loadCache = (): Record<number, ServerHealth> => {
    try {
        const raw = localStorage.getItem(HEALTH_CACHE_KEY);
        return raw ? JSON.parse(raw) : {};
    } catch {
        return {};
    }
};

const saveCache = (data: Record<number, ServerHealth>) => {
    try {
        localStorage.setItem(HEALTH_CACHE_KEY, JSON.stringify(data));
    } catch {
        // ignore quota errors
    }
};

let inMemory: Record<number, ServerHealth> = loadCache();

const withTimeout = async (promise: Promise<Response>): Promise<Response> => {
    const timeout = new Promise<Response>((_, reject) => {
        const id = setTimeout(() => {
            clearTimeout(id);
            reject(new Error('timeout'));
        }, TIMEOUT_MS);
    });
    return Promise.race([promise, timeout]) as Promise<Response>;
};

export const probeServer = async (url: string, serverId: number): Promise<ServerHealth> => {
    const start = performance.now();
    try {
        const res = await withTimeout(fetch(url, { method: 'HEAD', mode: 'no-cors' as RequestMode }));
        const latency = Math.max(1, Math.round(performance.now() - start));
        const health: ServerHealth = { serverId, latencyMs: latency, ok: true, checkedAt: Date.now() };
        inMemory[serverId] = health;
        saveCache(inMemory);
        return health;
    } catch {
        const health: ServerHealth = { serverId, latencyMs: null, ok: false, checkedAt: Date.now() };
        inMemory[serverId] = health;
        saveCache(inMemory);
        return health;
    }
};

export const getCachedHealth = (serverId: number): ServerHealth | null => {
    const h = inMemory[serverId];
    if (!h) return null;
    if (Date.now() - h.checkedAt > STALE_AFTER_MS) return null;
    return h;
};

export const rankServersByHealth = (serverIds: number[]): number[] => {
    return [...serverIds].sort((a, b) => {
        const ha = inMemory[a];
        const hb = inMemory[b];
        if (ha?.ok && hb?.ok) {
            return (ha.latencyMs ?? Infinity) - (hb.latencyMs ?? Infinity);
        }
        if (ha?.ok) return -1;
        if (hb?.ok) return 1;
        return (ha?.checkedAt ?? 0) - (hb?.checkedAt ?? 0);
    });
};

export const getAllHealth = (): Record<number, ServerHealth> => ({ ...inMemory });


