const CACHE_NAME = 'cinesphere-static-v1';
const TMDB_CACHE = 'cinesphere-tmdb-v1';
const STATIC_ASSETS = [
  '/',
  '/index.css',
  '/manifest.webmanifest'
];

self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME).then((cache) => cache.addAll(STATIC_ASSETS))
  );
  self.skipWaiting();
});

self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys().then((keys) => Promise.all(
      keys.filter(k => ![CACHE_NAME, TMDB_CACHE].includes(k)).map(k => caches.delete(k))
    ))
  );
  self.clients.claim();
});

// Helper to detect TMDB endpoints
const isTmdb = (url) => url.includes('image.tmdb.org/t/p') || url.includes('api.themoviedb.org/3');

self.addEventListener('fetch', (event) => {
  const { request } = event;
  const url = request.url;

  // Cache-first for TMDB images; stale-while-revalidate for metadata
  if (isTmdb(url)) {
    event.respondWith(
      (async () => {
        const cache = await caches.open(TMDB_CACHE);
        const cached = await cache.match(request);
        if (url.includes('image.tmdb.org')) {
          // Images: cache-first, then update in background
          if (cached) {
            event.waitUntil(fetch(request).then(res => { if (res.ok) cache.put(request, res.clone()); }));
            return cached;
          }
          const res = await fetch(request).catch(() => cached);
          if (res && res.ok) await cache.put(request, res.clone());
          return res || cached || Response.error();
        } else {
          // JSON metadata: stale-while-revalidate
          const networkPromise = fetch(request).then(async (res) => {
            if (res && res.ok) await cache.put(request, res.clone());
            return res;
          }).catch(() => cached);
          return cached ? Promise.resolve(cached) : networkPromise;
        }
      })()
    );
    return;
  }

  // Default: network first, fall back to cache
  event.respondWith(
    (async () => {
      try {
        const res = await fetch(request);
        return res;
      } catch (e) {
        const cache = await caches.open(CACHE_NAME);
        const cached = await cache.match(request);
        return cached || Response.error();
      }
    })()
  );
});


