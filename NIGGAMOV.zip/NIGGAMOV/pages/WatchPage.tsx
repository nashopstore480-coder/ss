import React, { useState, useEffect, useMemo, useRef } from 'react';
import { useSearchParams, useNavigate } from 'react-router-dom';
import { getMovieDetails, getTVShowDetails } from '../services/tmdbService';
import { addToViewingHistory } from '../services/historyService';
import { getInteractionShieldEnabled, setInteractionShieldEnabled } from '../services/settingsService';
import { Movie, TVShow, Media } from '../types';
import { getServerUrl, TMDB_IMAGE_BASE_URL, SERVERS } from '../constants';
import Loader from '../components/Loader';
import ServerSelector from '../components/ServerSelector';
import EpisodeSelector from '../components/EpisodeSelector';
import { useFullscreen } from '../hooks/useFullscreen';
import { CinemaModeIcon } from '../components/icons/CinemaModeIcon';
import { FullscreenIcon } from '../components/icons/FullscreenIcon';
import { StarIcon } from '../components/icons/StarIcon';
import { reportAdForServer } from '../services/adReportService';
import { 
  createAdBlockedIframe, 
  createInteractionShield, 
  monitorIframeActivity,
  getAdBlockSettings,
  isServerBlacklisted,
  blacklistServer
} from '../services/adBlockService';
import { WarningIcon } from '../components/icons/WarningIcon';
import { ShieldIcon } from '../components/icons/ShieldIcon';
import { PlayIcon } from '../components/icons/PlayIcon';
import { getCachedHealth, probeServer, rankServersByHealth } from '../services/serverHealthService';
import SecureDnsBanner from '../components/SecureDnsBanner';

interface WatchPageProps {
  openAiModal: (media: Media) => void; // deprecated
}

const WatchPage: React.FC<WatchPageProps> = ({ openAiModal }) => {
    const [searchParams, setSearchParams] = useSearchParams();
    const navigate = useNavigate();

    const type = searchParams.get('type') as 'movie' | 'tv' | null;
    const id = searchParams.get('id');
    const season = searchParams.get('s');
    const episode = searchParams.get('e');
    const serverId = parseInt(searchParams.get('server') || '1', 10);

    const [media, setMedia] = useState<Movie | TVShow | null>(null);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState<string | null>(null);
    const [isCinemaMode, setIsCinemaMode] = useState(false);
    const [reportTrigger, setReportTrigger] = useState(0);
    const [isInteractionShieldEnabled, setIsInteractionShieldEnabled] = useState(getInteractionShieldEnabled);
    const [isPlayerActive, setIsPlayerActive] = useState(false);
    const [adBlockSettings] = useState(getAdBlockSettings());

    const playerRef = useRef<HTMLDivElement>(null);
    const iframeRef = useRef<HTMLIFrameElement>(null);
    const { isFullscreen, toggleFullscreen } = useFullscreen(playerRef);

    useEffect(() => {
        if (!type || !id) {
            setError("Missing 'type' or 'id' in URL.");
            setLoading(false);
            return;
        }

        const fetchData = async () => {
            setLoading(true);
            setError(null);
            setMedia(null); // Clear previous media
            try {
                let data;
                if (type === 'movie') {
                    data = await getMovieDetails(id);
                } else if (type === 'tv' && season && episode) {
                    data = await getTVShowDetails(id);
                } else if (type === 'tv' && !season && !episode) { // Handle case where TV show is linked without S/E
                    navigate(`/watch?type=tv&id=${id}&s=1&e=1&server=${serverId}`);
                    return;
                }
                 else {
                    throw new Error("Invalid parameters for TV show.");
                }
                setMedia(data);
                window.scrollTo(0, 0);
            } catch (err) {
                console.error("Failed to fetch media details:", err);
                setError("Could not load media details. Please check the ID and try again.");
            } finally {
                setLoading(false);
            }
        };

        fetchData();
    }, [type, id, season, episode, navigate, serverId]);

    useEffect(() => {
        if (media && type) {
            // The media object from getMovieDetails/getTVShowDetails might not have media_type, so we add it from the URL.
            addToViewingHistory({ ...media, media_type: type });
        }
    }, [media, type]);
    
    const iframeSrc = useMemo(() => {
        if (!type || !id) return '';
        if (type === 'tv' && (!season || !episode)) return '';
        return getServerUrl(serverId, type, id, season ?? undefined, episode ?? undefined);
    }, [serverId, type, id, season, episode]);

    // Reset player activation when the source changes
    useEffect(() => {
        setIsPlayerActive(false);
    }, [iframeSrc]);

    // Probe current server on mount/change and opportunistically probe a few others
    useEffect(() => {
        (async () => {
            if (!type || !id) return;
            const currentUrl = getServerUrl(serverId, type, id, season ?? undefined, episode ?? undefined);
            // Probe current first to refresh cache
            probeServer(currentUrl, serverId).catch(() => {});
            // Also probe top 3 alternatives based on id order
            const alternatives = SERVERS.map(s => s.id).filter(id2 => id2 !== serverId).slice(0, 3);
            await Promise.all(alternatives.map(aid => {
                const url = getServerUrl(aid, type, id, season ?? undefined, episode ?? undefined);
                return probeServer(url, aid).catch(() => {});
            }));
        })();
    }, [serverId, type, id, season, episode]);

    // Auto-failover: if iframe doesn't load content quickly, switch to best healthy server
    useEffect(() => {
        if (!iframeRef.current) return;
        let timeoutId: number | undefined;
        const onLoad = () => {
            if (timeoutId) window.clearTimeout(timeoutId);
        };
        const iframe = iframeRef.current;
        iframe.addEventListener('load', onLoad);
        timeoutId = window.setTimeout(() => {
            const currentHealth = getCachedHealth(serverId);
            // If current server appears unhealthy or unknown, try switch
            if (!currentHealth || !currentHealth.ok) {
                const ranked = rankServersByHealth(SERVERS.map(s => s.id)).filter(id2 => id2 !== serverId);
                const candidate = ranked.find(id2 => {
                    const h = getCachedHealth(id2);
                    return h?.ok;
                });
                if (candidate) {
                    setSearchParams(prev => {
                        prev.set('server', String(candidate));
                        return prev;
                    }, { replace: true });
                }
            }
        }, 6000);
        return () => {
            iframe.removeEventListener('load', onLoad);
            if (timeoutId) window.clearTimeout(timeoutId);
        };
    }, [iframeSrc, serverId, setSearchParams]);

    const handleServerChange = (newServerId: number) => {
        setSearchParams(prev => {
            prev.set('server', newServerId.toString());
            return prev;
        }, { replace: true });
    };

    const handleEpisodeChange = (newSeason: number, newEpisode: number) => {
        navigate(`/watch?type=tv&id=${id}&s=${newSeason}&e=${newEpisode}&server=${serverId}`);
    };

    const handleReportAd = () => {
        reportAdForServer(serverId);
        setReportTrigger(c => c + 1);
    };

    const handleToggleInteractionShield = () => {
        const newState = !isInteractionShieldEnabled;
        setIsInteractionShieldEnabled(newState);
        setInteractionShieldEnabled(newState);
    };

    if (loading) {
        return <div className="flex justify-center items-center h-[calc(100vh-5rem)]"><Loader /></div>;
    }

    if (error) {
        return <div className="flex justify-center items-center h-[calc(100vh-5rem)] text-red-400 text-xl p-8 text-center">{error}</div>;
    }

    if (!media) {
        return <div className="flex justify-center items-center h-[calc(100vh-5rem)] text-gray-400">Select a movie or show to watch.</div>;
    }

    const title = media.title || media.name || 'Unknown Title';
    const displayTitle = type === 'tv' ? `${title} S${season} E${episode}` : title;
    const releaseYear = (media.release_date || media.first_air_date || '').split('-')[0];

    return (
        <div className={`transition-colors duration-300 ${isCinemaMode ? 'bg-black' : ''}`}>
            <div className="container mx-auto px-4 py-6">
                <SecureDnsBanner />
                <div ref={playerRef} className="player-container max-w-6xl mx-auto">
                <div className="aspect-w-16 aspect-h-9" id="iframe-container">
                    {isServerBlacklisted(serverId) ? (
                        <div className="w-full h-full flex items-center justify-center bg-gray-800 rounded-lg">
                            <div className="text-center">
                                <WarningIcon className="w-16 h-16 text-red-500 mx-auto mb-4" />
                                <h3 className="text-xl font-bold text-white mb-2">Server Blocked</h3>
                                <p className="text-gray-400 mb-4">This server has been blocked due to excessive ads.</p>
                                <button 
                                    onClick={() => window.location.reload()}
                                    className="px-4 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 transition-colors"
                                >
                                    Try Different Server
                                </button>
                            </div>
                        </div>
                    ) : (
                        <iframe
                            ref={iframeRef}
                            key={iframeSrc}
                            src={iframeSrc}
                            title="Media Player"
                            allow="autoplay; encrypted-media; picture-in-picture"
                            allowFullScreen
                            className="w-full h-full"
                            onLoad={() => {
                                if (iframeRef.current) {
                                    monitorIframeActivity(iframeRef.current);
                                }
                            }}
                        ></iframe>
                    )}
                </div>

                {isInteractionShieldEnabled && !isPlayerActive && !isServerBlacklisted(serverId) && (
                    <div 
                        className="player-overlay"
                        onClick={() => setIsPlayerActive(true)}
                        aria-label="Activate Player"
                        role="button"
                    >
                        <div className="player-activation-button">
                            <PlayIcon className="w-8 h-8 text-white" />
                        </div>
                        <div className="player-activation-text">
                            Click to activate player
                        </div>
                    </div>
                )}
                </div>
            </div>

            <div className={`container mx-auto p-4 md:p-8 transition-opacity duration-300 ${isCinemaMode ? 'opacity-0 invisible h-0 overflow-hidden' : 'opacity-100'}`}>
                <div className="flex flex-col md:flex-row justify-between md:items-center gap-4 mb-6">
                    <div>
                        <h1 className="text-3xl md:text-5xl font-extrabold text-white drop-shadow-lg">{displayTitle}</h1>
                        <div className="flex items-center gap-4 text-gray-400 mt-2">
                            <span>{releaseYear}</span>
                            <div className="flex items-center gap-1">
                                <StarIcon className="w-5 h-5 text-yellow-400" />
                                <span>{media.vote_average.toFixed(1)}</span>
                            </div>
                            <span>{media.genres?.map(g => g.name).join(', ')}</span>
                        </div>
                    </div>
                    <div className="flex items-center gap-2">
                        <button
                            onClick={handleToggleInteractionShield}
                            className={`p-2 rounded-full transition-colors ${isInteractionShieldEnabled ? 'bg-indigo-600 text-white' : 'bg-white/10 hover:bg-white/20'}`}
                            aria-label="Toggle Interaction Shield"
                            title="Interaction Shield: Captures the first click on the player to prevent pop-up ads. You may need to click twice to play."
                        >
                            <ShieldIcon className="w-6 h-6" />
                        </button>
                        <button onClick={() => setIsCinemaMode(c => !c)} className="p-2 rounded-full bg-white/10 hover:bg-white/20 transition-colors" aria-label="Cinema Mode">
                            <CinemaModeIcon className="w-6 h-6"/>
                        </button>
                        <button onClick={toggleFullscreen} className="p-2 rounded-full bg-white/10 hover:bg-white/20 transition-colors" aria-label="Fullscreen">
                           <FullscreenIcon className="w-6 h-6" isFullscreen={isFullscreen} />
                        </button>
                    </div>
                </div>

                <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                    <div className="lg:col-span-2 space-y-8">
                        <div>
                            <p className="text-gray-300 max-w-3xl">{media.overview}</p>
                        </div>
                    </div>
                    <div className="lg:col-span-1">
                         <div className="bg-black/30 backdrop-blur-md rounded-lg p-4 border border-white/10 space-y-6 sticky top-24">
                            <div>
                                <div className="flex justify-between items-center mb-4">
                                    <h3 className="text-xl font-bold">Servers</h3>
                                    <button
                                        onClick={handleReportAd}
                                        className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold rounded-full bg-yellow-500/10 text-yellow-300 hover:bg-yellow-500/20 transition-colors"
                                        title="Report intrusive ads on this server. This helps other users."
                                    >
                                        <WarningIcon className="w-4 h-4" />
                                        Report Ads
                                    </button>
                                </div>
                                <ServerSelector
                                    key={reportTrigger}
                                    currentServerId={serverId}
                                    onServerChange={handleServerChange}
                                />
                            </div>

                            {type === 'tv' && (
                                <div>
                                    <h3 className="text-xl font-bold mb-4">Episodes</h3>
                                    <EpisodeSelector 
                                        tvShow={media as TVShow} 
                                        currentSeason={parseInt(season!)} 
                                        currentEpisode={parseInt(episode!)} 
                                        onEpisodeChange={handleEpisodeChange}
                                    />
                                </div>
                            )}
                         </div>
                    </div>
                </div>
                
                {/* AI recommendations removed */}
            </div>
        </div>
    );
};

export default WatchPage;