import { useState, useCallback, useLayoutEffect, RefObject } from 'react';

type FullscreenApi = {
  requestFullscreen: (element: Element) => Promise<void>;
  exitFullscreen: () => Promise<void>;
  fullscreenElement: Element | null;
  fullscreenEnabled: boolean;
  // FIX: Correctly type `onfullscreenchange` as `string | null` to hold the event name.
  onfullscreenchange: string | null;
};

const getFullscreenApi = (): Partial<FullscreenApi> => {
  const doc = window.document as any;
  return {
    requestFullscreen: (
      doc.documentElement.requestFullscreen ||
      doc.documentElement.mozRequestFullScreen ||
      doc.documentElement.webkitRequestFullscreen ||
      doc.documentElement.msRequestFullscreen
    )?.bind(doc.documentElement),
    exitFullscreen: (
      doc.exitFullscreen ||
      doc.mozCancelFullScreen ||
      doc.webkitExitFullscreen ||
      doc.msExitFullscreen
    )?.bind(doc),
    fullscreenElement:
      doc.fullscreenElement ||
      doc.mozFullScreenElement ||
      doc.webkitFullscreenElement ||
      doc.msFullscreenElement,
    fullscreenEnabled:
      doc.fullscreenEnabled ||
      doc.mozFullScreenEnabled ||
      doc.webkitFullscreenEnabled ||
      doc.msFullscreenEnabled,
    // FIX: Return the correct event name (e.g., 'fullscreenchange') instead of the handler property name for use with addEventListener.
    onfullscreenchange:
      'onfullscreenchange' in doc ? 'fullscreenchange' :
      'onmozfullscreenchange' in doc ? 'mozfullscreenchange' :
      'onwebkitfullscreenchange' in doc ? 'webkitfullscreenchange' :
      'onmsfullscreenchange' in doc ? 'msfullscreenchange' :
      null,
  };
};

export const useFullscreen = (ref: RefObject<HTMLElement>) => {
  const [isFullscreen, setIsFullscreen] = useState(false);
  const api = getFullscreenApi();

  const toggleFullscreen = useCallback(async () => {
    if (!ref.current) return;
    
    const currentApi = getFullscreenApi();
    if (currentApi.fullscreenElement) {
      await currentApi.exitFullscreen?.();
    } else {
      await currentApi.requestFullscreen?.(ref.current);
    }
  }, [ref]);

  useLayoutEffect(() => {
    const handleChange = () => {
        const currentApi = getFullscreenApi();
        setIsFullscreen(!!currentApi.fullscreenElement);
    };

    if (api.onfullscreenchange) {
        document.addEventListener(api.onfullscreenchange, handleChange);
    }
    
    return () => {
        if (api.onfullscreenchange) {
            document.removeEventListener(api.onfullscreenchange, handleChange);
        }
    };
  }, [api.onfullscreenchange]);

  return { isFullscreen, toggleFullscreen, isEnabled: !!api.fullscreenEnabled };
};