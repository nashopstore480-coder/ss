import React, { useState, useEffect } from 'react';
import { TVShow, TVSeasonDetails } from '../types';
import { getTVSeasonDetails } from '../services/tmdbService';
import Loader from './Loader';
import { ChevronDownIcon } from './icons/ChevronDownIcon';

interface EpisodeSelectorProps {
    tvShow: TVShow;
    currentSeason: number;
    currentEpisode: number;
    onEpisodeChange: (season: number, episode: number) => void;
}

const EpisodeSelector: React.FC<EpisodeSelectorProps> = ({ tvShow, currentSeason, currentEpisode, onEpisodeChange }) => {
    const [selectedSeason, setSelectedSeason] = useState<number>(currentSeason);
    const [seasonDetails, setSeasonDetails] = useState<TVSeasonDetails | null>(null);
    const [loading, setLoading] = useState(false);

    useEffect(() => {
        const fetchDetails = async () => {
            setLoading(true);
            try {
                const details = await getTVSeasonDetails(tvShow.id.toString(), selectedSeason);
                setSeasonDetails(details);
            } catch (error) {
                console.error("Failed to fetch season details", error);
                setSeasonDetails(null);
            } finally {
                setLoading(false);
            }
        };
        fetchDetails();
    }, [selectedSeason, tvShow.id]);
    
    // Filter out season 0 (Specials) if it exists
    const seasons = tvShow.seasons.filter(s => s.season_number !== 0);

    return (
        <div className="space-y-4">
            <div className="relative">
                 <select
                    value={selectedSeason}
                    onChange={(e) => setSelectedSeason(Number(e.target.value))}
                    className="w-full bg-gray-700/50 text-white p-3 rounded-md appearance-none focus:outline-none focus:ring-2 focus:ring-indigo-500 cursor-pointer"
                >
                    {seasons.map(season => (
                        <option key={season.season_number} value={season.season_number}>
                            Season {season.season_number}
                        </option>
                    ))}
                </select>
                <div className="pointer-events-none absolute inset-y-0 right-0 flex items-center px-2 text-gray-400">
                    <ChevronDownIcon className="w-5 h-5" />
                </div>
            </div>

            <div className="max-h-64 overflow-y-auto pr-2">
                {loading ? <div className="flex justify-center py-4"><Loader/></div> : (
                    <div className="grid grid-cols-3 sm:grid-cols-4 lg:grid-cols-3 xl:grid-cols-4 gap-2">
                        {seasonDetails?.episodes.map(ep => (
                            <button
                                key={ep.episode_number}
                                onClick={() => onEpisodeChange(selectedSeason, ep.episode_number)}
                                className={`p-2 text-xs text-center font-semibold rounded-md transition-all duration-200 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-gray-800 focus:ring-indigo-500
                                ${currentSeason === selectedSeason && currentEpisode === ep.episode_number 
                                    ? 'bg-indigo-600 text-white' 
                                    : 'bg-gray-700/50 text-gray-300 hover:bg-gray-600/70'
                                }`}
                            >
                                Ep {ep.episode_number}
                            </button>
                        ))}
                    </div>
                )}
            </div>
        </div>
    );
};

export default EpisodeSelector;
