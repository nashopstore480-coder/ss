import React from 'react';
import { Cast } from '../types';
import { TMDB_IMAGE_BASE_URL } from '../constants';

interface CastGridProps {
    cast: Cast[];
}

const CastGrid: React.FC<CastGridProps> = ({ cast }) => {
    return (
        <div>
            <h2 className="text-2xl font-bold mb-4 text-indigo-300">Top Billed Cast</h2>
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-4">
                {cast.map(member => (
                    <div key={member.id} className="text-center">
                        <img 
                            src={member.profile_path ? `${TMDB_IMAGE_BASE_URL}/w185${member.profile_path}` : 'https://via.placeholder.com/185x278.png?text=No+Photo'}
                            alt={member.name}
                            className="rounded-lg shadow-md mb-2 mx-auto w-full h-auto aspect-[2/3] object-cover bg-gray-800"
                            loading="lazy"
                        />
                        <p className="font-bold text-white text-sm">{member.name}</p>
                        <p className="text-gray-400 text-xs">{member.character}</p>
                    </div>
                ))}
            </div>
        </div>
    );
};

export default CastGrid;
