import React from 'react';
import { Link } from 'react-router-dom';
import { PlayIcon } from './icons/PlayIcon';

const Header: React.FC = () => {
  return (
    <header className="fixed top-0 left-0 w-full z-20 bg-gray-900/50 backdrop-blur-lg border-b border-white/10">
      <div className="container mx-auto flex justify-between items-center py-3 px-4 sm:px-6 lg:px-8">
        <Link to="/" className="flex items-center gap-2 text-2xl font-bold text-white hover:text-indigo-400 transition-colors">
          <PlayIcon className="w-8 h-8 text-indigo-500" />
          <span>niggamov</span>
        </Link>
        {/* Navigation links can be added here */}
      </div>
    </header>
  );
};

export default Header;
