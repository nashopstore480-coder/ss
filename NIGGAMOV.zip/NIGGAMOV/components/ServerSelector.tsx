import React, { useMemo } from 'react';
import { SERVERS } from '../constants';
import { getAdReports } from '../services/adReportService';
import { 
  isServerBlacklisted, 
  blacklistServer, 
  whitelistServer,
  getAdBlockSettings 
} from '../services/adBlockService';
import { WarningIcon } from './icons/WarningIcon';
import { ShieldIcon } from './icons/ShieldIcon';
import { getCachedHealth } from '../services/serverHealthService';

interface ServerSelectorProps {
    currentServerId: number;
    onServerChange: (serverId: number) => void;
}

const ServerSelector: React.FC<ServerSelectorProps> = ({ currentServerId, onServerChange }) => {
    const sortedServers = useMemo(() => {
        const reports = getAdReports();
        return [...SERVERS].sort((a, b) => {
            // Prefer healthier servers (ok with lower latency)
            const ha = getCachedHealth(a.id);
            const hb = getCachedHealth(b.id);
            if (ha?.ok && hb?.ok) {
                const la = ha.latencyMs ?? Infinity;
                const lb = hb.latencyMs ?? Infinity;
                if (la !== lb) return la - lb;
            } else if (ha?.ok) {
                return -1;
            } else if (hb?.ok) {
                return 1;
            }
            // Fallback to fewest ad reports
            const countA = reports[a.id] || 0;
            const countB = reports[b.id] || 0;
            if (countA !== countB) {
                return countA - countB;
            }
            return a.id - b.id; // stable sort for equal metrics
        });
    }, []);

    const adReports = getAdReports();
    const adBlockSettings = getAdBlockSettings();

    const handleServerClick = (serverId: number) => {
        if (isServerBlacklisted(serverId)) {
            // If server is blacklisted, ask user if they want to unblock it
            if (window.confirm('This server has been blocked due to ads. Do you want to unblock it?')) {
                whitelistServer(serverId);
                onServerChange(serverId);
            }
        } else {
            onServerChange(serverId);
        }
    };

    const handleBlacklistServer = (serverId: number, e: React.MouseEvent) => {
        e.stopPropagation();
        if (window.confirm('Block this server due to ads?')) {
            blacklistServer(serverId);
            // Force re-render by updating a dummy state
            window.location.reload();
        }
    };

    return (
        <div className="grid grid-cols-3 sm:grid-cols-4 md:grid-cols-5 gap-2">
            {sortedServers.map(server => {
                const reportCount = adReports[server.id] || 0;
                const isBlacklisted = isServerBlacklisted(server.id);

                return (
                    <button
                        key={server.id}
                        onClick={() => handleServerClick(server.id)}
                        className={`px-3 py-2 text-sm font-semibold rounded-md transition-all duration-200 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-gray-800 focus:ring-indigo-500 relative group
                        ${isBlacklisted
                            ? 'bg-red-900/50 text-red-300 border border-red-500/50'
                            : currentServerId === server.id
                            ? 'bg-indigo-600 text-white shadow-lg'
                            : 'bg-gray-700/50 text-gray-300 hover:bg-gray-600/70'
                        }`}
                        title={
                            isBlacklisted 
                                ? `Server ${server.name} - BLOCKED (Click to unblock)`
                                : reportCount > 0 
                                ? `Server ${server.name} (${reportCount} user(s) reported ads) - Right-click to block`
                                : `Server ${server.name} - Right-click to block if ads appear`
                        }
                        onContextMenu={(e) => {
                            e.preventDefault();
                            if (!isBlacklisted) {
                                handleBlacklistServer(server.id, e);
                            }
                        }}
                    >
                        {server.id}
                        {/* Health indicator (cached) */}
                        {(() => {
                            const h = getCachedHealth(server.id);
                            if (!h) return null;
                            const color = h.ok
                                ? (h.latencyMs && h.latencyMs <= 1200 ? 'bg-green-400' : 'bg-yellow-400')
                                : 'bg-red-500';
                            const title = h.ok
                                ? `Healthy • ~${h.latencyMs ?? '?'} ms`
                                : 'Unreachable recently';
                            return (
                                <span className="absolute -bottom-1 -right-1" title={title}>
                                    <span className={`inline-flex rounded-full h-2.5 w-2.5 border-2 border-gray-900/80 ${color}`}></span>
                                </span>
                            );
                        })()}
                        
                        {/* Ad warning indicators */}
                        {reportCount > 2 && !isBlacklisted && (
                             <span className="absolute -top-1 -right-1 flex h-3 w-3">
                                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-red-400 opacity-75"></span>
                                <span className="relative inline-flex rounded-full h-3 w-3 bg-red-500 border-2 border-gray-900/80"></span>
                            </span>
                        )}
                        {reportCount > 0 && reportCount <= 2 && !isBlacklisted && (
                             <span className="absolute -top-1 -right-1 flex h-3 w-3">
                                <span className="relative inline-flex rounded-full h-3 w-3 bg-yellow-400 border-2 border-gray-900/80"></span>
                            </span>
                        )}
                        
                        {/* Blocked indicator */}
                        {isBlacklisted && (
                            <span className="absolute -top-1 -right-1 flex h-3 w-3">
                                <WarningIcon className="w-3 h-3 text-red-500" />
                            </span>
                        )}
                        
                        {/* Ad block shield indicator */}
                        {adBlockSettings.enabled && !isBlacklisted && (
                            <span className="absolute -bottom-1 -left-1 opacity-0 group-hover:opacity-100 transition-opacity">
                                <ShieldIcon className="w-3 h-3 text-green-400" />
                            </span>
                        )}
                    </button>
                );
            })}
        </div>
    );
};

export default ServerSelector;