import React from 'react';

export const ChatBotIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M7.5 8.25h9m-9 3H12m-9.75 1.51c0 1.6 1.123 2.994 2.707 3.227 1.129.166 2.27.293 3.423.325 3.498.097 7.032-.423 10.378-1.757a2.115 2.115 0 001.255-2.121c-.24-1.85-.94-3.536-1.897-4.996a18.375 18.375 0 00-5.434-5.232C12.8 3.02 12.405 3 12 3c-1.5 0-2.847.42-4.005 1.185A18.375 18.375 0 003.103 9.486c-.957 1.46-1.657 3.146-1.897 4.996a2.115 2.115 0 001.255 2.121z" />
  </svg>
);
